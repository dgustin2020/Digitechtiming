#!/bin/sh

#script per eseguire l'aggiornamento del cronometro
#deve fermare eventuali programmi in esecuzione, compreso il demone seriali
#deve verificare che i file estratti non contengano errori
#fermati i programmi inizia a copiare i vari dati
#dopo aver copiato tutto devo programmare pure i micri

#CHECK=0

#verifica il md5sum della directory di lavoro (dal file chksum.md5)
#se è ok procede cerca se ci sono sotto directory e nel caso passa a quelle
VERIFICA_MD5SUM() {
  if [ -f chksum.md5 ]      #se il file esiste
  then
    echo "verifico md5sum in $PWD"
    md5sum -c chksum.md5      #faccio la verifica
    if [ $? -eq 0 ]           #se il risultato è positivo
      then                    #allora cerco se ci sono sottodirectory
        for file in *
        do
          if [ -d "$file" ]   #se è una directory
            then
              cd "$file"        #ci entro
              VERIFICA_MD5SUM   #e calcolo il checksum
              cd ..
            fi
        done
        
      else
        echo "errore md5sum in $PWD"
        exit 1
      fi
  fi
}

echo "mi sposto nella directory temporanea"
cd /tmp/aggiorna/tarTmp

echo "verifico il checksum dei file d'aggiornamento"

VERIFICA_MD5SUM

echo "fine aggiornamento"
exit 0
