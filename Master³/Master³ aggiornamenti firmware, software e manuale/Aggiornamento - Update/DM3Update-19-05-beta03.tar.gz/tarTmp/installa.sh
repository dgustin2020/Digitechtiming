#!/bin/sh


#copio i file nel posto giusto
#però per farlo devo rendere scrivibile la partizione
#copio tutti i file e poi eseguo 'aggiornaLPC' per aggiornare i micri

echo "monto la partizione in lettura/scrittura"
rw

echo "elimino i file di configurazione"
#sync
#umount -f /home/
#mkfs.ext2 /dev/hda3
#mount /dev/hda3 
#mkdir /home/sysConf

rm /home/sysConf/*.conf
rm /home/sysConf/version
rm /home/gare/*
rm -rf /home/gare/semSeq

#elimino tutti i programmi vecchi così se passo da una versione di setup
#ad una normale spariscono i programmi speciali
echo "elimino i vecchi programmi"
rm /usr/bin/DM3*

TMPDIR=/tmp/aggiorna/tarTmp

echo "copio i nuovi programmi"
cp $TMPDIR/lib/*.so /usr/lib/master/
cp $TMPDIR/bin/*  /usr/bin/
cp $TMPDIR/bin/img/* /usr/bin/img/
cp $TMPDIR/bin/testi/* /usr/bin/testi/
cp $TMPDIR/version /home/sysConf/
cp $TMPDIR/support/* /usr/bin/

echo "copia eseguita"

echo "verifico se devo aggiornare lo script di avvio"
LINE="# Configuring eth0"
LINE2="ethtool -s eth0 speed 10 duplex full autoneg off"
FILE=/etc/init.d/rcS
grep "$LINE" $FILE
if [ $? -eq 0 ]
then
  echo "già aggiornato"
else
  echo "devo aggiornare"
  echo "$LINE" >> "$FILE" 
  echo "$LINE2" >> "$FILE"
fi

echo "aggiorno i microcontrollori"

$TMPDIR/aggiornaLPC

#qui non ci arrivo mai perché dopo aver aggiornato i micri riavvio
echo "qualcosa è andato storto"

